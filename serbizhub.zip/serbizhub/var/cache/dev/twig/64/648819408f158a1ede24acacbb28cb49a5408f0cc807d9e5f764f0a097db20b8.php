<?php

/* serbizhub/contact.html.twig */
class __TwigTemplate_b40dccdbb056e92c5aacd42ff48bca3e31ee52325613925ced950bbea7465600 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("contactbase.html.twig", "serbizhub/contact.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "contactbase.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "serbizhub/contact.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo " SerbizHub Website ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "\t 

\t


    <!--Map-->
    <div class=\"map-clean\">
    <div class=\"container\">
        <div class=\"intro\">
        </div>
    </div><iframe allowfullscreen frameborder=\"0\" width=\"100%\" height=\"450\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3859.9915840080544!2d121.06948407154454!3d14.656419033102505!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397b766f967e55f%3A0x4e1938ebba579e4!2sNational+Engineering+Center%2C+Apacible+St%2C+Diliman%2C+Quezon+City%2C+Metro+Manila!5e0!3m2!1sen!2sph!4v1476429444126\" ></iframe></div>
    <!--EndMap-->
\t<link rel=\"stylesheet\" type=\"text/css\" href=\"xrc/css/util.css\">
\t<link rel=\"stylesheet\" type=\"text/css\" href=\"xrc/css/main.css\"> 

    <div class=\"container-contact100\">
\t\t<div class=\"wrap-contact100\">
\t\t\t<form class=\"contact100-form validate-form\">
\t\t\t\t<span class=\"contact100-form-title\">
\t\t\t\t\tSend Us A Message
\t\t\t\t</span>

\t\t\t\t<label class=\"label-input100\" for=\"first-name\">Tell us your name *</label>
\t\t\t\t<div class=\"wrap-input100 rs1-wrap-input100 validate-input\" data-validate=\"Type first name\">
\t\t\t\t\t<input id=\"first-name\" class=\"input100\" type=\"text\" name=\"first-name\" placeholder=\"First name\">
\t\t\t\t\t<span class=\"focus-input100\"></span>
\t\t\t\t</div>
\t\t\t\t<div class=\"wrap-input100 rs2-wrap-input100 validate-input\" data-validate=\"Type last name\">
\t\t\t\t\t<input class=\"input100\" type=\"text\" name=\"last-name\" placeholder=\"Last name\">
\t\t\t\t\t<span class=\"focus-input100\"></span>
\t\t\t\t</div>

\t\t\t\t<label class=\"label-input100\" for=\"email\">Enter your email *</label>
\t\t\t\t<div class=\"wrap-input100 validate-input\" data-validate = \"Valid email is required: ex@abc.xyz\">
\t\t\t\t\t<input id=\"email\" class=\"input100\" type=\"text\" name=\"email\" placeholder=\"Eg. example@gmail.com\">
\t\t\t\t\t<span class=\"focus-input100\"></span>
\t\t\t\t</div>

\t\t\t\t<label class=\"label-input100\" for=\"phone\">Enter phone number</label>
\t\t\t\t<div class=\"wrap-input100\">
\t\t\t\t\t<input id=\"phone\" class=\"input100\" type=\"text\" name=\"phone\" placeholder=\"Eg. +63 9000000 000\">
\t\t\t\t\t<span class=\"focus-input100\"></span>
\t\t\t\t</div>

\t\t\t\t<label class=\"label-input100\" for=\"message\">Message *</label>
\t\t\t\t<div class=\"wrap-input100 validate-input\" data-validate = \"Message is required\">
\t\t\t\t\t<textarea id=\"message\" class=\"input100\" name=\"message\" placeholder=\"Write us a message\"></textarea>
\t\t\t\t\t<span class=\"focus-input100\"></span>
\t\t\t\t</div>

\t\t\t\t<div class=\"container-contact100-form-btn\">
\t\t\t\t\t<button class=\"contact100-form-btn\">
\t\t\t\t\t\tSend Message
\t\t\t\t\t</button>
\t\t\t\t</div>
\t\t\t</form>

\t\t\t<div class=\"contact100-more flex-col-c-m\" style=\"background-image: url('images/bg-01.jpg');\">
\t\t\t\t<div class=\"flex-w size1 p-b-47\">
\t\t\t\t\t<div class=\"txt1 p-r-25\">
\t\t\t\t\t\t<span class=\"lnr lnr-map-marker\"></span>
\t\t\t\t\t</div>

\t\t\t\t\t<div class=\"flex-col size2\">
\t\t\t\t\t\t<span class=\"txt1 p-b-20\">
\t\t\t\t\t\t\tAddress
\t\t\t\t\t\t</span>

\t\t\t\t\t\t<span class=\"txt2\">
\t\t\t\t\t\t\tEntreprise Program for Technopreneurship<br>
                            3/F National Engineering Center<br>
                            University of the Philippines<br>
                            Diliman, Quezon City
\t\t\t\t\t\t</span>
\t\t\t\t\t</div>
\t\t\t\t</div>

\t\t\t\t<div class=\"dis-flex size1 p-b-47\">
\t\t\t\t\t<div class=\"txt1 p-r-25\">
\t\t\t\t\t\t<span class=\"lnr lnr-phone-handset\"></span>
\t\t\t\t\t</div>

\t\t\t\t\t<div class=\"flex-col size2\">
\t\t\t\t\t\t<span class=\"txt1 p-b-20\">
\t\t\t\t\t\t\tLets Talk
\t\t\t\t\t\t</span>

\t\t\t\t\t\t<span class=\"txt3\">
\t\t\t\t\t\t\t(+63 2) 652 6922 <br>
                            (+63) 917 137 8589
\t\t\t\t\t\t</span>
\t\t\t\t\t</div>
\t\t\t\t</div>

\t\t\t\t<div class=\"dis-flex size1 p-b-47\">
\t\t\t\t\t<div class=\"txt1 p-r-25\">
\t\t\t\t\t\t<span class=\"lnr lnr-envelope\"></span>
\t\t\t\t\t</div>

\t\t\t\t\t<div class=\"flex-col size2\">
\t\t\t\t\t\t<span class=\"txt1 p-b-20\">
\t\t\t\t\t\t\tGeneral Support
\t\t\t\t\t\t</span>

\t\t\t\t\t\t<span class=\"txt3\">
\t\t\t\t\t\t\tcontact@moodlearning.com
\t\t\t\t\t\t</span>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>



\t<div id=\"dropDownSelect1\"></div>

\t\t<script src=\"vendor/jquery/jquery-3.2.1.min.js\"></script>

\t<script src=\"vendor/animsition/js/animsition.min.js\"></script>

\t<script src=\"vendor/bootstrap/js/popper.js\"></script>
\t<script src=\"vendor/bootstrap/js/bootstrap.min.js\"></script>

\t<script src=\"vendor/select2/select2.min.js\"></script>
\t<script>
\t\t\$(\".selection-2\").select2({
\t\t\tminimumResultsForSearch: 20,
\t\t\tdropdownParent: \$('#dropDownSelect1')
\t\t});
\t</script>

\t<script src=\"vendor/daterangepicker/moment.min.js\"></script>
\t<script src=\"vendor/daterangepicker/daterangepicker.js\"></script>

\t<script src=\"vendor/countdowntime/countdowntime.js\"></script>

\t<script src=\"js/main.js\"></script>
\t<!-- Global site tag (gtag.js) - Google Analytics -->
\t<script async src=\"https://www.googletagmanager.com/gtag/js?id=UA-23581568-13\"></script>
\t<script>
\t  window.dataLayer = window.dataLayer || [];
\t  function gtag(){dataLayer.push(arguments);}
\t  gtag('js', new Date());

\t  gtag('config', 'UA-23581568-13');
\t</script>




    <!--Orange-->
    <div class=\"card\" style=\"max-width: 1000;\">
        <img class=\"card-img\" src=\"/img/orange.png\" alt=\"Card image\">
        <div class=\"card-img-overlay\">
            <div class=\"row featurette\" >
    
            </div>
        </div>
    </div>
    <!--end of features-->
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "serbizhub/contact.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 6,  51 => 5,  39 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'contactbase.html.twig' %}

{% block title %} SerbizHub Website {% endblock %}

{% block body %}
\t 

\t


    <!--Map-->
    <div class=\"map-clean\">
    <div class=\"container\">
        <div class=\"intro\">
        </div>
    </div><iframe allowfullscreen frameborder=\"0\" width=\"100%\" height=\"450\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3859.9915840080544!2d121.06948407154454!3d14.656419033102505!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397b766f967e55f%3A0x4e1938ebba579e4!2sNational+Engineering+Center%2C+Apacible+St%2C+Diliman%2C+Quezon+City%2C+Metro+Manila!5e0!3m2!1sen!2sph!4v1476429444126\" ></iframe></div>
    <!--EndMap-->
\t<link rel=\"stylesheet\" type=\"text/css\" href=\"xrc/css/util.css\">
\t<link rel=\"stylesheet\" type=\"text/css\" href=\"xrc/css/main.css\"> 

    <div class=\"container-contact100\">
\t\t<div class=\"wrap-contact100\">
\t\t\t<form class=\"contact100-form validate-form\">
\t\t\t\t<span class=\"contact100-form-title\">
\t\t\t\t\tSend Us A Message
\t\t\t\t</span>

\t\t\t\t<label class=\"label-input100\" for=\"first-name\">Tell us your name *</label>
\t\t\t\t<div class=\"wrap-input100 rs1-wrap-input100 validate-input\" data-validate=\"Type first name\">
\t\t\t\t\t<input id=\"first-name\" class=\"input100\" type=\"text\" name=\"first-name\" placeholder=\"First name\">
\t\t\t\t\t<span class=\"focus-input100\"></span>
\t\t\t\t</div>
\t\t\t\t<div class=\"wrap-input100 rs2-wrap-input100 validate-input\" data-validate=\"Type last name\">
\t\t\t\t\t<input class=\"input100\" type=\"text\" name=\"last-name\" placeholder=\"Last name\">
\t\t\t\t\t<span class=\"focus-input100\"></span>
\t\t\t\t</div>

\t\t\t\t<label class=\"label-input100\" for=\"email\">Enter your email *</label>
\t\t\t\t<div class=\"wrap-input100 validate-input\" data-validate = \"Valid email is required: ex@abc.xyz\">
\t\t\t\t\t<input id=\"email\" class=\"input100\" type=\"text\" name=\"email\" placeholder=\"Eg. example@gmail.com\">
\t\t\t\t\t<span class=\"focus-input100\"></span>
\t\t\t\t</div>

\t\t\t\t<label class=\"label-input100\" for=\"phone\">Enter phone number</label>
\t\t\t\t<div class=\"wrap-input100\">
\t\t\t\t\t<input id=\"phone\" class=\"input100\" type=\"text\" name=\"phone\" placeholder=\"Eg. +63 9000000 000\">
\t\t\t\t\t<span class=\"focus-input100\"></span>
\t\t\t\t</div>

\t\t\t\t<label class=\"label-input100\" for=\"message\">Message *</label>
\t\t\t\t<div class=\"wrap-input100 validate-input\" data-validate = \"Message is required\">
\t\t\t\t\t<textarea id=\"message\" class=\"input100\" name=\"message\" placeholder=\"Write us a message\"></textarea>
\t\t\t\t\t<span class=\"focus-input100\"></span>
\t\t\t\t</div>

\t\t\t\t<div class=\"container-contact100-form-btn\">
\t\t\t\t\t<button class=\"contact100-form-btn\">
\t\t\t\t\t\tSend Message
\t\t\t\t\t</button>
\t\t\t\t</div>
\t\t\t</form>

\t\t\t<div class=\"contact100-more flex-col-c-m\" style=\"background-image: url('images/bg-01.jpg');\">
\t\t\t\t<div class=\"flex-w size1 p-b-47\">
\t\t\t\t\t<div class=\"txt1 p-r-25\">
\t\t\t\t\t\t<span class=\"lnr lnr-map-marker\"></span>
\t\t\t\t\t</div>

\t\t\t\t\t<div class=\"flex-col size2\">
\t\t\t\t\t\t<span class=\"txt1 p-b-20\">
\t\t\t\t\t\t\tAddress
\t\t\t\t\t\t</span>

\t\t\t\t\t\t<span class=\"txt2\">
\t\t\t\t\t\t\tEntreprise Program for Technopreneurship<br>
                            3/F National Engineering Center<br>
                            University of the Philippines<br>
                            Diliman, Quezon City
\t\t\t\t\t\t</span>
\t\t\t\t\t</div>
\t\t\t\t</div>

\t\t\t\t<div class=\"dis-flex size1 p-b-47\">
\t\t\t\t\t<div class=\"txt1 p-r-25\">
\t\t\t\t\t\t<span class=\"lnr lnr-phone-handset\"></span>
\t\t\t\t\t</div>

\t\t\t\t\t<div class=\"flex-col size2\">
\t\t\t\t\t\t<span class=\"txt1 p-b-20\">
\t\t\t\t\t\t\tLets Talk
\t\t\t\t\t\t</span>

\t\t\t\t\t\t<span class=\"txt3\">
\t\t\t\t\t\t\t(+63 2) 652 6922 <br>
                            (+63) 917 137 8589
\t\t\t\t\t\t</span>
\t\t\t\t\t</div>
\t\t\t\t</div>

\t\t\t\t<div class=\"dis-flex size1 p-b-47\">
\t\t\t\t\t<div class=\"txt1 p-r-25\">
\t\t\t\t\t\t<span class=\"lnr lnr-envelope\"></span>
\t\t\t\t\t</div>

\t\t\t\t\t<div class=\"flex-col size2\">
\t\t\t\t\t\t<span class=\"txt1 p-b-20\">
\t\t\t\t\t\t\tGeneral Support
\t\t\t\t\t\t</span>

\t\t\t\t\t\t<span class=\"txt3\">
\t\t\t\t\t\t\tcontact@moodlearning.com
\t\t\t\t\t\t</span>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>



\t<div id=\"dropDownSelect1\"></div>

\t\t<script src=\"vendor/jquery/jquery-3.2.1.min.js\"></script>

\t<script src=\"vendor/animsition/js/animsition.min.js\"></script>

\t<script src=\"vendor/bootstrap/js/popper.js\"></script>
\t<script src=\"vendor/bootstrap/js/bootstrap.min.js\"></script>

\t<script src=\"vendor/select2/select2.min.js\"></script>
\t<script>
\t\t\$(\".selection-2\").select2({
\t\t\tminimumResultsForSearch: 20,
\t\t\tdropdownParent: \$('#dropDownSelect1')
\t\t});
\t</script>

\t<script src=\"vendor/daterangepicker/moment.min.js\"></script>
\t<script src=\"vendor/daterangepicker/daterangepicker.js\"></script>

\t<script src=\"vendor/countdowntime/countdowntime.js\"></script>

\t<script src=\"js/main.js\"></script>
\t<!-- Global site tag (gtag.js) - Google Analytics -->
\t<script async src=\"https://www.googletagmanager.com/gtag/js?id=UA-23581568-13\"></script>
\t<script>
\t  window.dataLayer = window.dataLayer || [];
\t  function gtag(){dataLayer.push(arguments);}
\t  gtag('js', new Date());

\t  gtag('config', 'UA-23581568-13');
\t</script>




    <!--Orange-->
    <div class=\"card\" style=\"max-width: 1000;\">
        <img class=\"card-img\" src=\"/img/orange.png\" alt=\"Card image\">
        <div class=\"card-img-overlay\">
            <div class=\"row featurette\" >
    
            </div>
        </div>
    </div>
    <!--end of features-->
{% endblock %}


", "serbizhub/contact.html.twig", "C:\\xampp\\htdocs\\serbizhub\\templates\\serbizhub\\contact.html.twig");
    }
}
