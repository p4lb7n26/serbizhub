<?php

/* serbizhub/about.html.twig */
class __TwigTemplate_53fc88480bdd21e8d995cb7a5601cd4bf90c6e9f7328228cab3190e43b386afc extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "serbizhub/about.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "serbizhub/about.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo " SerbizHub Website ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "
    <!--Carousel -->
    <div id=\"myCarousel\" class=\"carousel slide\" data-ride=\"carousel\">
        <div class=\"carousel-inner\" role=\"listbox\">
            <div class=\"carousel-item active\">
                <img class=\"first-slide\" src=\"img/aboutbackground.jpg\" alt=\"First slide\">
                <div class=\"container\">
                <div class=\"carousel-caption d-none d-md-block\"> </div>
                </div>
            </div>
        </div>
    </div>
    <!--Carousel End-->

    <!--Features-->
    <div class=\"features-clean\">
        <div class=\"container\" style=\"background-size:cover;background-position:bottom;background-color:#ffffff;\">
            <center><h2>We believe in the power of ideas</h2></center>
            <br>
            <div class=\"row features\">
                <div class=\"col-sm-6 col-lg-4   item\">
                    <h3 class=\"name\">Who We Are</h3>
                    <p class=\"description\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Mauris in aliquam sem fringilla ut. Tortor vitae purus faucibus ornare suspendisse sed nisi lacus sed. Potenti nullam ac tortor vitae purus faucibus ornare suspendisse sed. In hendrerit gravida rutrum quisque non tellus orci ac auctor. Arcu dictum varius duis at. Sed nisi lacus sed viverra tellus in.</p>
                </div>
                <div class=\"col-sm-6 col-lg-4   item\">
                    <h3 class=\"name\">What We Do</h3>
                    <p class=\"description\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. In vitae turpis massa sed elementum. Aenean vel elit scelerisque mauris pellentesque pulvinar pellentesque. Lacus laoreet non curabitur gravida arcu ac tortor. Velit scelerisque in dictum non consectetur a erat nam.</p>
                </div>
                <div class=\"col-sm-6 col-lg-4   item\">
                    <h3 class=\"name\">How We Work</h3>
                    <p class=\"description\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Curabitur gravida arcu ac tortor dignissim convallis aenean. Elementum curabitur vitae nunc sed velit dignissim sodales. Faucibus scelerisque eleifend donec pretium. Odio facilisis mauris sit amet massa vitae tortor condimentum lacinia. Volutpat consequat mauris nunc congue nisi vitae suscipit tellus mauris.</p>
                </div>
            </div>
        </div>
    </div>
    <div class=\"card\" style=\"max-width: 1000;\">
        <img class=\"card-img\" height=\"100\" src=\"/img/orange1.png\" alt=\"Card image\">
        <div class=\"card-img-overlay\">
            <div class=\"row featurette\" >
                <div class=\"col-md-9\">
                <h3 style=\"color:white;\">Check out our portfolio now</h3>
                </div>
                <div class=\"col-md-3\">
                <button type=\"button\" class=\"btn btn-secondary\">Explore</button>
                </div>
            </div>
        </div>
    </div>
    <!--end of features-->

    

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "serbizhub/about.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 6,  51 => 5,  39 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block title %} SerbizHub Website {% endblock %}

{% block body %}

    <!--Carousel -->
    <div id=\"myCarousel\" class=\"carousel slide\" data-ride=\"carousel\">
        <div class=\"carousel-inner\" role=\"listbox\">
            <div class=\"carousel-item active\">
                <img class=\"first-slide\" src=\"img/aboutbackground.jpg\" alt=\"First slide\">
                <div class=\"container\">
                <div class=\"carousel-caption d-none d-md-block\"> </div>
                </div>
            </div>
        </div>
    </div>
    <!--Carousel End-->

    <!--Features-->
    <div class=\"features-clean\">
        <div class=\"container\" style=\"background-size:cover;background-position:bottom;background-color:#ffffff;\">
            <center><h2>We believe in the power of ideas</h2></center>
            <br>
            <div class=\"row features\">
                <div class=\"col-sm-6 col-lg-4   item\">
                    <h3 class=\"name\">Who We Are</h3>
                    <p class=\"description\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Mauris in aliquam sem fringilla ut. Tortor vitae purus faucibus ornare suspendisse sed nisi lacus sed. Potenti nullam ac tortor vitae purus faucibus ornare suspendisse sed. In hendrerit gravida rutrum quisque non tellus orci ac auctor. Arcu dictum varius duis at. Sed nisi lacus sed viverra tellus in.</p>
                </div>
                <div class=\"col-sm-6 col-lg-4   item\">
                    <h3 class=\"name\">What We Do</h3>
                    <p class=\"description\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. In vitae turpis massa sed elementum. Aenean vel elit scelerisque mauris pellentesque pulvinar pellentesque. Lacus laoreet non curabitur gravida arcu ac tortor. Velit scelerisque in dictum non consectetur a erat nam.</p>
                </div>
                <div class=\"col-sm-6 col-lg-4   item\">
                    <h3 class=\"name\">How We Work</h3>
                    <p class=\"description\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Curabitur gravida arcu ac tortor dignissim convallis aenean. Elementum curabitur vitae nunc sed velit dignissim sodales. Faucibus scelerisque eleifend donec pretium. Odio facilisis mauris sit amet massa vitae tortor condimentum lacinia. Volutpat consequat mauris nunc congue nisi vitae suscipit tellus mauris.</p>
                </div>
            </div>
        </div>
    </div>
    <div class=\"card\" style=\"max-width: 1000;\">
        <img class=\"card-img\" height=\"100\" src=\"/img/orange1.png\" alt=\"Card image\">
        <div class=\"card-img-overlay\">
            <div class=\"row featurette\" >
                <div class=\"col-md-9\">
                <h3 style=\"color:white;\">Check out our portfolio now</h3>
                </div>
                <div class=\"col-md-3\">
                <button type=\"button\" class=\"btn btn-secondary\">Explore</button>
                </div>
            </div>
        </div>
    </div>
    <!--end of features-->

    

{% endblock %}


", "serbizhub/about.html.twig", "C:\\xampp\\htdocs\\serbizhub\\templates\\serbizhub\\about.html.twig");
    }
}
