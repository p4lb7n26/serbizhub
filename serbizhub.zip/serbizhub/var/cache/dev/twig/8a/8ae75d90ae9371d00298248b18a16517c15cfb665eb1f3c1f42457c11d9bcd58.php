<?php

/* inc/foot.html.twig */
class __TwigTemplate_f3d5cca256d1934fd851d25b2c9233ebab4bd2f94fdbc0f1407a77cd988fff41 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "inc/foot.html.twig"));

        // line 1
        echo "<!-- FOOTER -->
<footer style=\"margin:0px;\">
    <div class=\"row\">
        <div class=\"col-sm-6 col-md-4 footer-navigation\">
            <h3></h3><img src=\"/img/logo1.png\" />
            <p class=\"company-name\"><strong>Copyright ©</strong><a href=\"https://moodlearning.com/\"><strong>moodLearning, Inc.</strong></a><strong>2011-8.</strong><br /></p>
        </div>
        <div class=\"col-sm-6 col-md-4 footer-contacts\">
            <div><span class=\"fa fa-map-marker footer-contacts-icon\"></span>
                <p><span class=\"new-line-span\" style=\"font-size:11px;\">Entreprise Program for Technopreneurship<br />3/F National Engineering Center<br />University of the Philippines<br /></span>Diliman, Quezon City</p>
            </div>
            
        </div>
        <div class=\"clearfix\"></div>
        <div class=\"col-md-4 footer-about\">
            <div><i class=\"fa fa-phone footer-contacts-icon\"></i>
                <p class=\"footer-center-info email text-left\">(+63 2) 652 6922<br />(+63) 917 137 8589<br /></p>
            </div>
            <div><i class=\"fa fa-envelope footer-contacts-icon\"></i>
                <p><a href=\"#\" target=\"_blank\">contact@moodlearning.com<br /></a></p>
            </div>
        </div>
    </div>
</footer>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "inc/foot.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!-- FOOTER -->
<footer style=\"margin:0px;\">
    <div class=\"row\">
        <div class=\"col-sm-6 col-md-4 footer-navigation\">
            <h3></h3><img src=\"/img/logo1.png\" />
            <p class=\"company-name\"><strong>Copyright ©</strong><a href=\"https://moodlearning.com/\"><strong>moodLearning, Inc.</strong></a><strong>2011-8.</strong><br /></p>
        </div>
        <div class=\"col-sm-6 col-md-4 footer-contacts\">
            <div><span class=\"fa fa-map-marker footer-contacts-icon\"></span>
                <p><span class=\"new-line-span\" style=\"font-size:11px;\">Entreprise Program for Technopreneurship<br />3/F National Engineering Center<br />University of the Philippines<br /></span>Diliman, Quezon City</p>
            </div>
            
        </div>
        <div class=\"clearfix\"></div>
        <div class=\"col-md-4 footer-about\">
            <div><i class=\"fa fa-phone footer-contacts-icon\"></i>
                <p class=\"footer-center-info email text-left\">(+63 2) 652 6922<br />(+63) 917 137 8589<br /></p>
            </div>
            <div><i class=\"fa fa-envelope footer-contacts-icon\"></i>
                <p><a href=\"#\" target=\"_blank\">contact@moodlearning.com<br /></a></p>
            </div>
        </div>
    </div>
</footer>", "inc/foot.html.twig", "C:\\xampp\\htdocs\\serbizhub\\templates\\inc\\foot.html.twig");
    }
}
