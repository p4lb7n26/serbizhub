<?php

/* serbizhub/services.html.twig */
class __TwigTemplate_2f922463e3f49f7479a158795c5c57aa9d1f0148de561ef80fce477d502c5005 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "serbizhub/services.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "serbizhub/services.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo " SerbizHub Website ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "
<link rel=\"stylesheet\" href=\"/css/car1.css\">
    <!--Services-->
    <div class=\"features-clean\">
        <div class=\"container\" style=\"background-size:cover;background-position:bottom;background-color:#ffffff;\">
            <br>
            <center><h2>SerbizHub Services</h2></center>
            <br>
        </div>  
    </div>

    <div class=\"card\" style=\"max-width: 1000;\">
        <img class=\"card-img\" height=\"1300\" src=\"/img/orange1.png\" alt=\"Card image\">
            <br> <br>
            <div class=\"card-img-overlay\">
                <div class=\"row features\">
                    <div class=\"col-sm-6 col-lg-4   item\">
                        <center><img height=\"100\" width=\"100\" src=\"/img/serbizsuite.png\" alt=\"suite\">
                        <h3 class=\"name\" style=\"color:#453d3d\">SerbizHub Suite</h3> 
                        <p style=\"color:white;\">incorporates sales, inventory, accounting functions; manages purchase orders, invoices, accounts payable and receivable, inventories, payments, general ledgers, banking records. (Flyer, Technical Specs. Demo access is available upon request. </center>
                    </div>
                    <div class=\"col-sm-6 col-lg-4   item\">
                        <center><img height=\"100\" width=\"100\" src=\"/img/peoplesuite.png\" alt=\"suite\">
                        <h3 class=\"name\" style=\"color:#453d3d\">peopleSuite</h3> 
                        <p style=\"color:white;\">a human resource platform for personnel records, for managing time and attendance, leaves, payroll. The system integrates biometric devices. (Brochure. Demo is available upon request.) </center>
                    </div>
                    <div class=\"col-sm-6 col-lg-4   item\">
                        <center><img height=\"100\" width=\"100\" src=\"/img/help.png\" alt=\"suite\">
                        <h3 class=\"name\" style=\"color:#453d3d\">SerbizHub HelpDesk</h3> 
                        <p style=\"color:white;\">a support ticket system to address customer complaints, queries, inter-department concerns. It enables you to consolidate communication channels (email, phone, SMS) for efficient customer service. See brochure. </center>
                    </div>
                    <div class=\"col-sm-6 col-lg-4   item\">
                        <center><img height=\"100\" width=\"100\" src=\"/img/links.png\" alt=\"suite\">
                        <h3 class=\"name\" style=\"color:#453d3d\">SerbizHub Links</h3> 
                        <p style=\"color:white;\">helps manage your interactions with customers, automate sales and marketing processes, analyze customer data, and create reports. Demo available.</center>
                    </div>
                    <div class=\"col-sm-6 col-lg-4   item\">
                        <center><img height=\"100\" width=\"100\" src=\"/img/health.png\" alt=\"suite\">
                        <h3 class=\"name\" style=\"color:#453d3d\">Content Management System</h3> 
                        <p style=\"color:white;\">Don't just build a website that easily turns into an online relic. Create a secure, dynamic, highly manageable, mobile-ready, social-media friendly platform meant to be found by search engines and revisted many times over.</center>
                    </div>
                    <div class=\"col-sm-6 col-lg-4   item\">
                        <center><img height=\"100\" width=\"100\" src=\"/img/bank.png\" alt=\"suite\">
                        <h3 class=\"name\" style=\"color:#453d3d\">SerbizHub Banking</h3> 
                        <p style=\"color:white;\">a banking platform for credit cooperatives for managing membership information, loans and credits, payments, remittances, and for generating reports and alerts. Access to demo site is available upon request.</center>
                    </div>
                    <div class=\"col-sm-6 col-lg-4   item\">
                        <center><img height=\"100\" width=\"100\" src=\"/img/mail.png\" alt=\"suite\">
                        <h3 class=\"name\" style=\"color:#453d3d\">SerbizHub Mail</h3> 
                        <p style=\"color:white;\">Using official email is a mark of professionalism and good business etiquette. SerbizHub Mail is a reliable, affordable, well-maintained custom email service accessible from diverse devices. More details.</center>
                    </div>
                    <div class=\"col-sm-6 col-lg-4   item\">
                        <center><img height=\"100\" width=\"100\" src=\"/img/collaborate.png\" alt=\"suite\">
                        <h3 class=\"name\" style=\"color:#453d3d\">SerbizHub Collaborate</h3> 
                        <p style=\"color:white;\">is a host of collaboration platforms that foster productivity, document and knowledge management, and institutional memory. It provides a repository of various organizational digital assets accessible from diverse devices.</center>
                    </div>
                    <div class=\"col-sm-6 col-lg-4   item\">
                        <center><img height=\"100\" width=\"100\" src=\"/img/support.png\" alt=\"suite\">
                        <h3 class=\"name\" style=\"color:#453d3d\">SerbizHub Support</h3> 
                        <p style=\"color:white;\">Can't bring yourself to build your own IT department? Let us be your virtual technology support. We do remote server mangement and analytics and can assist in planning, deployment, monitoring of IT services.</center>
                    </div>
                    <div class=\"col-sm-6 col-lg-4   item\">
                        <center><img height=\"100\" width=\"100\" src=\"/img/sec.png\" alt=\"suite\">
                        <h3 class=\"name\" style=\"color:#453d3d\">SerbizHub Consulting</h3> 
                        <p style=\"color:white;\">The requirements of online security are dynamic and ever-changing. The need to periodically, independently evaluate online security risks and threats to business, is more pressing than ever. moodLearning offers security consulting that includes vulnerability assessment and penetration testing of online assets.</center>
                    </div>
                    <div class=\"col-sm-6 col-lg-4   item\">
                        <center><img height=\"100\" width=\"100\" src=\"/img/knowledge.png\" alt=\"suite\">
                        <h3 class=\"name\" style=\"color:#453d3d\">Knowledge Management</h3> 
                        <p style=\"color:white;\">Knowledge can be a transformative asset. moodLearning offers knowledge management consulting to help businesses and organizations identify, document, develop, streamline, share, deploy good business processes or practices and achieve their missions and goals.</center>
                    </div>
                    <div class=\"col-sm-6 col-lg-4   item\">
                        <center><img height=\"100\" width=\"100\" src=\"/img/tech.png\" alt=\"suite\">
                        <h3 class=\"name\" style=\"color:#453d3d\">Technology Management</h3> 
                        <p style=\"color:white;\">Technologies have not always been wielded to your own full advantage. moodLearning offers technology management consulting that helps businesses and organizations examine and develop their strategies and options for deploying appropriate and effective technologies.</center>
                    </div>
                </div>
            </div>    
        </div>
    </div>
    <!--EndServices-->

    <!--Carousel -->
    <div id=\"myCarousel2\" class=\"carousel slide\" data-ride=\"carousel\">

        <ol class=\"carousel-indicators\">
            <li data-target=\"#myCarousel2\" data-slide-to=\"0\" class=\"active\"></li>
            <li data-target=\"#myCarousel2\" data-slide-to=\"1\"></li>
            <li data-target=\"#myCarousel2\" data-slide-to=\"2\"></li>
            <li data-target=\"#myCarousel2\" data-slide-to=\"3\"></li>
            <li data-target=\"#myCarousel2\" data-slide-to=\"4\"></li>
        </ol>

        <div class=\"carousel-inner\" role=\"listbox\">
            <div class=\"carousel-item active\">
                <img class=\"first-slide\" height=\"200\" width=\"200\" src=\"img/services1.jpg\" alt=\"First slide\">
                <div class=\"container\">
                <div class=\"carousel-caption d-none d-md-block\">
                
                </div>
            </div>
        </div>
        <div class=\"carousel-item\">
            <img class=\"second-slide\" height=\"200\" width=\"200\" src=\"img/services2.jpg\" alt=\"Second slide\">
                <div class=\"container\">
                    <div class=\"carousel-caption d-none d-md-block\">
                        
                    </div>
                </div>
            </div>
            <div class=\"carousel-item\">
                <img class=\"third-slide\" height=\"200\" width=\"200\" src=\"img/services3.jpg\" alt=\"Third slide\">
                <div class=\"container\">
                    <div class=\"carousel-caption d-none d-md-block text-right\">
                        
                    </div>
                </div>
            </div>
            <div class=\"carousel-item\">
                <img class=\"fourth-slide\" height=\"200\" width=\"200\" src=\"img/services4.jpg\" alt=\"Fourth slide\">
                <div class=\"container\">
                    <div class=\"carousel-caption d-none d-md-block text-right\">
                       
                    </div>
                </div>
            </div>
            <div class=\"carousel-item\">
                <img class=\"fifth-slide\" height=\"200\" width=\"200\" src=\"img/services5.jpg\" alt=\"Fifth slide\">
                <div class=\"container\">
                    <div class=\"carousel-caption d-none d-md-block text-right\">
                
                    </div>
                </div>
            </div>
        </div>

        <a class=\"carousel-control-prev\" href=\"#myCarousel2\" role=\"button\" data-slide=\"prev\">
            <span class=\"carousel-control-prev-icon\" aria-hidden=\"true\"></span>
            <span class=\"sr-only\">Previous</span>
        </a>
        <a class=\"carousel-control-next\" href=\"#myCarousel2\" role=\"button\" data-slide=\"next\">
            <span class=\"carousel-control-next-icon\" aria-hidden=\"true\"></span>
            <span class=\"sr-only\">Next</span>
        </a>
    </div>
    <!--CarouselEnd-->

    <div class=\"card\" style=\"max-width: 1000;\">
        <img class=\"card-img\" height=\"300\" src=\"/img/aboutback.png\" alt=\"Card image\">
        <div class=\"card-img-overlay\">
                <br> <br>
                <center>
                <h3 style=\"color:white;\">Discover what we can do for you today!</h3>
                <p> Talk to us at <br> 
                (+63 2) 652 6922 <br>(+63) 917 137 8589 </p>
                
                <a href=\"/contact\"><button type=\"button\" class=\"btn btn-secondary\">Contact Us</button></a>
                </center>
        </div>
        </div>
    </div>
    <div class=\"card\" style=\"max-width: 1000;\">
        <img class=\"card-img\" height=\"70\" src=\"/img/orange1.png\" alt=\"Card image\">
        <div class=\"card-img-overlay\">
            
        </div>
    </div>

    

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "serbizhub/services.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 7,  51 => 6,  39 => 5,  15 => 2,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("
{% extends 'base.html.twig' %}


{% block title %} SerbizHub Website {% endblock %}
{% block body %}

<link rel=\"stylesheet\" href=\"/css/car1.css\">
    <!--Services-->
    <div class=\"features-clean\">
        <div class=\"container\" style=\"background-size:cover;background-position:bottom;background-color:#ffffff;\">
            <br>
            <center><h2>SerbizHub Services</h2></center>
            <br>
        </div>  
    </div>

    <div class=\"card\" style=\"max-width: 1000;\">
        <img class=\"card-img\" height=\"1300\" src=\"/img/orange1.png\" alt=\"Card image\">
            <br> <br>
            <div class=\"card-img-overlay\">
                <div class=\"row features\">
                    <div class=\"col-sm-6 col-lg-4   item\">
                        <center><img height=\"100\" width=\"100\" src=\"/img/serbizsuite.png\" alt=\"suite\">
                        <h3 class=\"name\" style=\"color:#453d3d\">SerbizHub Suite</h3> 
                        <p style=\"color:white;\">incorporates sales, inventory, accounting functions; manages purchase orders, invoices, accounts payable and receivable, inventories, payments, general ledgers, banking records. (Flyer, Technical Specs. Demo access is available upon request. </center>
                    </div>
                    <div class=\"col-sm-6 col-lg-4   item\">
                        <center><img height=\"100\" width=\"100\" src=\"/img/peoplesuite.png\" alt=\"suite\">
                        <h3 class=\"name\" style=\"color:#453d3d\">peopleSuite</h3> 
                        <p style=\"color:white;\">a human resource platform for personnel records, for managing time and attendance, leaves, payroll. The system integrates biometric devices. (Brochure. Demo is available upon request.) </center>
                    </div>
                    <div class=\"col-sm-6 col-lg-4   item\">
                        <center><img height=\"100\" width=\"100\" src=\"/img/help.png\" alt=\"suite\">
                        <h3 class=\"name\" style=\"color:#453d3d\">SerbizHub HelpDesk</h3> 
                        <p style=\"color:white;\">a support ticket system to address customer complaints, queries, inter-department concerns. It enables you to consolidate communication channels (email, phone, SMS) for efficient customer service. See brochure. </center>
                    </div>
                    <div class=\"col-sm-6 col-lg-4   item\">
                        <center><img height=\"100\" width=\"100\" src=\"/img/links.png\" alt=\"suite\">
                        <h3 class=\"name\" style=\"color:#453d3d\">SerbizHub Links</h3> 
                        <p style=\"color:white;\">helps manage your interactions with customers, automate sales and marketing processes, analyze customer data, and create reports. Demo available.</center>
                    </div>
                    <div class=\"col-sm-6 col-lg-4   item\">
                        <center><img height=\"100\" width=\"100\" src=\"/img/health.png\" alt=\"suite\">
                        <h3 class=\"name\" style=\"color:#453d3d\">Content Management System</h3> 
                        <p style=\"color:white;\">Don't just build a website that easily turns into an online relic. Create a secure, dynamic, highly manageable, mobile-ready, social-media friendly platform meant to be found by search engines and revisted many times over.</center>
                    </div>
                    <div class=\"col-sm-6 col-lg-4   item\">
                        <center><img height=\"100\" width=\"100\" src=\"/img/bank.png\" alt=\"suite\">
                        <h3 class=\"name\" style=\"color:#453d3d\">SerbizHub Banking</h3> 
                        <p style=\"color:white;\">a banking platform for credit cooperatives for managing membership information, loans and credits, payments, remittances, and for generating reports and alerts. Access to demo site is available upon request.</center>
                    </div>
                    <div class=\"col-sm-6 col-lg-4   item\">
                        <center><img height=\"100\" width=\"100\" src=\"/img/mail.png\" alt=\"suite\">
                        <h3 class=\"name\" style=\"color:#453d3d\">SerbizHub Mail</h3> 
                        <p style=\"color:white;\">Using official email is a mark of professionalism and good business etiquette. SerbizHub Mail is a reliable, affordable, well-maintained custom email service accessible from diverse devices. More details.</center>
                    </div>
                    <div class=\"col-sm-6 col-lg-4   item\">
                        <center><img height=\"100\" width=\"100\" src=\"/img/collaborate.png\" alt=\"suite\">
                        <h3 class=\"name\" style=\"color:#453d3d\">SerbizHub Collaborate</h3> 
                        <p style=\"color:white;\">is a host of collaboration platforms that foster productivity, document and knowledge management, and institutional memory. It provides a repository of various organizational digital assets accessible from diverse devices.</center>
                    </div>
                    <div class=\"col-sm-6 col-lg-4   item\">
                        <center><img height=\"100\" width=\"100\" src=\"/img/support.png\" alt=\"suite\">
                        <h3 class=\"name\" style=\"color:#453d3d\">SerbizHub Support</h3> 
                        <p style=\"color:white;\">Can't bring yourself to build your own IT department? Let us be your virtual technology support. We do remote server mangement and analytics and can assist in planning, deployment, monitoring of IT services.</center>
                    </div>
                    <div class=\"col-sm-6 col-lg-4   item\">
                        <center><img height=\"100\" width=\"100\" src=\"/img/sec.png\" alt=\"suite\">
                        <h3 class=\"name\" style=\"color:#453d3d\">SerbizHub Consulting</h3> 
                        <p style=\"color:white;\">The requirements of online security are dynamic and ever-changing. The need to periodically, independently evaluate online security risks and threats to business, is more pressing than ever. moodLearning offers security consulting that includes vulnerability assessment and penetration testing of online assets.</center>
                    </div>
                    <div class=\"col-sm-6 col-lg-4   item\">
                        <center><img height=\"100\" width=\"100\" src=\"/img/knowledge.png\" alt=\"suite\">
                        <h3 class=\"name\" style=\"color:#453d3d\">Knowledge Management</h3> 
                        <p style=\"color:white;\">Knowledge can be a transformative asset. moodLearning offers knowledge management consulting to help businesses and organizations identify, document, develop, streamline, share, deploy good business processes or practices and achieve their missions and goals.</center>
                    </div>
                    <div class=\"col-sm-6 col-lg-4   item\">
                        <center><img height=\"100\" width=\"100\" src=\"/img/tech.png\" alt=\"suite\">
                        <h3 class=\"name\" style=\"color:#453d3d\">Technology Management</h3> 
                        <p style=\"color:white;\">Technologies have not always been wielded to your own full advantage. moodLearning offers technology management consulting that helps businesses and organizations examine and develop their strategies and options for deploying appropriate and effective technologies.</center>
                    </div>
                </div>
            </div>    
        </div>
    </div>
    <!--EndServices-->

    <!--Carousel -->
    <div id=\"myCarousel2\" class=\"carousel slide\" data-ride=\"carousel\">

        <ol class=\"carousel-indicators\">
            <li data-target=\"#myCarousel2\" data-slide-to=\"0\" class=\"active\"></li>
            <li data-target=\"#myCarousel2\" data-slide-to=\"1\"></li>
            <li data-target=\"#myCarousel2\" data-slide-to=\"2\"></li>
            <li data-target=\"#myCarousel2\" data-slide-to=\"3\"></li>
            <li data-target=\"#myCarousel2\" data-slide-to=\"4\"></li>
        </ol>

        <div class=\"carousel-inner\" role=\"listbox\">
            <div class=\"carousel-item active\">
                <img class=\"first-slide\" height=\"200\" width=\"200\" src=\"img/services1.jpg\" alt=\"First slide\">
                <div class=\"container\">
                <div class=\"carousel-caption d-none d-md-block\">
                
                </div>
            </div>
        </div>
        <div class=\"carousel-item\">
            <img class=\"second-slide\" height=\"200\" width=\"200\" src=\"img/services2.jpg\" alt=\"Second slide\">
                <div class=\"container\">
                    <div class=\"carousel-caption d-none d-md-block\">
                        
                    </div>
                </div>
            </div>
            <div class=\"carousel-item\">
                <img class=\"third-slide\" height=\"200\" width=\"200\" src=\"img/services3.jpg\" alt=\"Third slide\">
                <div class=\"container\">
                    <div class=\"carousel-caption d-none d-md-block text-right\">
                        
                    </div>
                </div>
            </div>
            <div class=\"carousel-item\">
                <img class=\"fourth-slide\" height=\"200\" width=\"200\" src=\"img/services4.jpg\" alt=\"Fourth slide\">
                <div class=\"container\">
                    <div class=\"carousel-caption d-none d-md-block text-right\">
                       
                    </div>
                </div>
            </div>
            <div class=\"carousel-item\">
                <img class=\"fifth-slide\" height=\"200\" width=\"200\" src=\"img/services5.jpg\" alt=\"Fifth slide\">
                <div class=\"container\">
                    <div class=\"carousel-caption d-none d-md-block text-right\">
                
                    </div>
                </div>
            </div>
        </div>

        <a class=\"carousel-control-prev\" href=\"#myCarousel2\" role=\"button\" data-slide=\"prev\">
            <span class=\"carousel-control-prev-icon\" aria-hidden=\"true\"></span>
            <span class=\"sr-only\">Previous</span>
        </a>
        <a class=\"carousel-control-next\" href=\"#myCarousel2\" role=\"button\" data-slide=\"next\">
            <span class=\"carousel-control-next-icon\" aria-hidden=\"true\"></span>
            <span class=\"sr-only\">Next</span>
        </a>
    </div>
    <!--CarouselEnd-->

    <div class=\"card\" style=\"max-width: 1000;\">
        <img class=\"card-img\" height=\"300\" src=\"/img/aboutback.png\" alt=\"Card image\">
        <div class=\"card-img-overlay\">
                <br> <br>
                <center>
                <h3 style=\"color:white;\">Discover what we can do for you today!</h3>
                <p> Talk to us at <br> 
                (+63 2) 652 6922 <br>(+63) 917 137 8589 </p>
                
                <a href=\"/contact\"><button type=\"button\" class=\"btn btn-secondary\">Contact Us</button></a>
                </center>
        </div>
        </div>
    </div>
    <div class=\"card\" style=\"max-width: 1000;\">
        <img class=\"card-img\" height=\"70\" src=\"/img/orange1.png\" alt=\"Card image\">
        <div class=\"card-img-overlay\">
            
        </div>
    </div>

    

{% endblock %}


", "serbizhub/services.html.twig", "C:\\xampp\\htdocs\\serbizhub\\templates\\serbizhub\\services.html.twig");
    }
}
