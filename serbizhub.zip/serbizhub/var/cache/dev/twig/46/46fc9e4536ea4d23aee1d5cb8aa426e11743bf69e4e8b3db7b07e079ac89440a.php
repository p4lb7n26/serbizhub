<?php

/* serbizhub/careers.html.twig */
class __TwigTemplate_e6889ae098e6bbdd0809336816d1a6a9b225f4afc76a2c2a5b536765169f31be extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "serbizhub/careers.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "serbizhub/careers.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo " SerbizHub Website ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <!--Services-->
    <div class=\"features-clean\">
        <div class=\"container\" style=\"background-size:cover;background-position:bottom;background-color:#ffffff;\">
            <br>
            <center><h2>Careers</h2>
            <p> serbizHub welcomes developers, coders, marketeers, consultants seeking work-life balance as well as personal and professional growth in a progressive environment.
            <br><br> Visit <br><br> <a href=\"http://moodlearning.com/jobs\" style=\"color:#f37021\"> moodlearning.com/jobs</a> <br> for more details. </p> </center>
            <br>
        </div>  
    </div>

    
    <div class=\"card\" style=\"max-width: 1000;\">
        <img class=\"card-img\" height=\"70\" src=\"/img/orange1.png\" alt=\"Card image\">
        <div class=\"card-img-overlay\">
            
        </div>
    </div>

    

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "serbizhub/careers.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 6,  51 => 5,  39 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block title %} SerbizHub Website {% endblock %}

{% block body %}
    <!--Services-->
    <div class=\"features-clean\">
        <div class=\"container\" style=\"background-size:cover;background-position:bottom;background-color:#ffffff;\">
            <br>
            <center><h2>Careers</h2>
            <p> serbizHub welcomes developers, coders, marketeers, consultants seeking work-life balance as well as personal and professional growth in a progressive environment.
            <br><br> Visit <br><br> <a href=\"http://moodlearning.com/jobs\" style=\"color:#f37021\"> moodlearning.com/jobs</a> <br> for more details. </p> </center>
            <br>
        </div>  
    </div>

    
    <div class=\"card\" style=\"max-width: 1000;\">
        <img class=\"card-img\" height=\"70\" src=\"/img/orange1.png\" alt=\"Card image\">
        <div class=\"card-img-overlay\">
            
        </div>
    </div>

    

{% endblock %}


", "serbizhub/careers.html.twig", "C:\\xampp\\htdocs\\serbizhub\\templates\\serbizhub\\careers.html.twig");
    }
}
