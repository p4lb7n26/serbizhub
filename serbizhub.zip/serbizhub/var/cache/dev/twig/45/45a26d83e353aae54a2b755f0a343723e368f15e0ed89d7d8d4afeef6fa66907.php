<?php

/* inc/navbar.html.twig */
class __TwigTemplate_3828c7daa51eae552208bf07b35566dd44ec1e771835f857e14d5686a4ad513f extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "inc/navbar.html.twig"));

        // line 1
        echo "<link rel=\"stylesheet\" href=\"/css/active.css\">
<link rel=\"stylesheet\" href=\"/js/active.min.js\">
<nav class=\"navbar navbar-expand-lg navbar-light bg-light\">
  <a class=\"navbar-brand\" href=\"#\"><img height=\"50\" width=\"200\" src=\"/img/serbizhub1.png\"></a>
  <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarColor03\" aria-controls=\"navbarColor03\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
    <span class=\"navbar-toggler-icon\"></span>
  </button>

  <div class=\"collapse navbar-collapse\" id=\"navbarColor03\">
    <ul class=\"navbar-nav mr-auto\">
      
    </ul>
    <div id=\"myDIV\">
      <ul class=\"navbar-nav\">
        <li class=\"nav-item\">
          <a class=\"nav-link\" href=\"/\">Home <span class=\"sr-only\">(current)</span></a>
        
        </li>
        <li class=\"nav-item\">
          <a class=\"nav-link\" href=\"/services\">Services</a>
       
        </li>
        <li class=\"nav-item\">
          <a class=\"nav-link\" href=\"/about\">About</a>
        </li>
        <li class=\"nav-item\">
          <a class=\"nav-link\" href=\"/careers\">Careers</a>
        </li>
        <li class=\"nav-item\">
          <a class=\"nav-link\" href=\"/contact\">Contact Us</a>
        </li>
      </ul>
    </div>
  </div>
</nav>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "inc/navbar.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<link rel=\"stylesheet\" href=\"/css/active.css\">
<link rel=\"stylesheet\" href=\"/js/active.min.js\">
<nav class=\"navbar navbar-expand-lg navbar-light bg-light\">
  <a class=\"navbar-brand\" href=\"#\"><img height=\"50\" width=\"200\" src=\"/img/serbizhub1.png\"></a>
  <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarColor03\" aria-controls=\"navbarColor03\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
    <span class=\"navbar-toggler-icon\"></span>
  </button>

  <div class=\"collapse navbar-collapse\" id=\"navbarColor03\">
    <ul class=\"navbar-nav mr-auto\">
      
    </ul>
    <div id=\"myDIV\">
      <ul class=\"navbar-nav\">
        <li class=\"nav-item\">
          <a class=\"nav-link\" href=\"/\">Home <span class=\"sr-only\">(current)</span></a>
        
        </li>
        <li class=\"nav-item\">
          <a class=\"nav-link\" href=\"/services\">Services</a>
       
        </li>
        <li class=\"nav-item\">
          <a class=\"nav-link\" href=\"/about\">About</a>
        </li>
        <li class=\"nav-item\">
          <a class=\"nav-link\" href=\"/careers\">Careers</a>
        </li>
        <li class=\"nav-item\">
          <a class=\"nav-link\" href=\"/contact\">Contact Us</a>
        </li>
      </ul>
    </div>
  </div>
</nav>", "inc/navbar.html.twig", "C:\\xampp\\htdocs\\serbizhub\\templates\\inc\\navbar.html.twig");
    }
}
